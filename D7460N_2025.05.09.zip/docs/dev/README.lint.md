| File | Status | Effort | Last Updated | Acceptance |
|------|--------|--------|---------------|------------|
| `_README.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `.git/hooks/README.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `assets/_README.md` | — | — | — | — |
| `assets/css/_README.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `assets/js/_README.md` | — | — | — | — |
| `assets/images/_README.md` | — | — | — | — |
| `assets/images/brand/logo.svg/_README.md` | — | — | — | — |
| `docs/_README.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `docs/dev/accessibility.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `docs/dev/comparison.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `docs/dev/data.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `docs/dev/forms.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `docs/dev/index.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `docs/dev/layout.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `docs/dev/performance.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `docs/dev/routing.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
| `docs/dev/_README.md` | — | — | — | — |
| `data/_README.md` | doc:status WIP | doc:effort TBD | doc:updated 2025-05-04 | 0/2 complete |
